/*
 * Created on Jan 12, 2005
 */

/**
 * @author Mik Kersten
 */
public class NoMembers {

}
