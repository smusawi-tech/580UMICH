package pack;

public class C {

	public int x = 2;
	
	void method() {
	}
	
	public String method1() {
		return "";
	}
	
	private String method2(){
		return "";
	}
	
}
