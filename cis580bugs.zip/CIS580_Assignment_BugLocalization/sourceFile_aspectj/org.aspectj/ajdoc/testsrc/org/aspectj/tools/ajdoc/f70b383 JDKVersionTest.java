/* *******************************************************************
 * Copyright (c) 2005 Contributors.
 * All rights reserved. 
 * This program and the accompanying materials are made available 
 * under the terms of the Eclipse Public License v1.0 
 * which accompanies this distribution and is available at 
 * http://www.eclipse.org/legal/epl-v10.html 
 *  
 * Contributors: 
 *     Mik Kersten     initial implementation 
 * ******************************************************************/
package org.aspectj.tools.ajdoc;


/**
 * @author Mik Kersten
 */
public class JDKVersionTest extends AjdocTestCase {

//    public void testIsUsing1point4() {
//        String v = System.getProperty("java.class.version","44.0");
//        assertTrue(("49.0".compareTo(v) > 0) && ("48.0".compareTo(v) <= 0));
//        assertFalse(Util.isExecutingOnJava5());
//    }

    public void testNothing() {}
//    public void testIsUsing1point5() {
//        assertTrue(Util.isExecutingOnJava5());
//    }
    
}
