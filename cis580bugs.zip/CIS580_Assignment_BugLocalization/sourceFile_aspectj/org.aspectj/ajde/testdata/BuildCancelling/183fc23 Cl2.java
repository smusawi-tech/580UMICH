public class Cl2 {
	public static void main(String[] args) {
	}
}